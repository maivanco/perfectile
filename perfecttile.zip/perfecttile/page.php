<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

get_header();

/* Start the Loop */
while ( have_posts() ) :
	the_post();

	get_template_part('template-parts/general/page-banner');
?>

	<section id="page-content">
		<div class="container">
			<h1 class="page-title"><?php the_title();?></h1>
			<div class="entry-content">
				<?php the_content();?>
			</div>
		</div>
	</section>

<?php


endwhile; // End of the loop.

get_footer();
