<?php
$current_year = date('Y');

$copyright_text = get_acf_option('footer_copyright_text') ?? __('Copyright &copy; %s Perfectile. All rights reserved.', 'perfiectitle');
$copyright_text = sprintf($copyright_text, $current_year);

$footer_form_id = (int) get_field('footer_form', 'option');

?>

	</main>
	<footer id='site-footer' class='footer'>
		<div class='footer__triangle'></div>
		<div class="footer__inside">
			<div class='container'>
				<div class='footer__wrapper'>
					<div class='left'>

						<?php get_template_part('template-parts/footer/logo');?>
						<?php get_template_part('template-parts/footer/nav-menu');?>

						<?php get_template_part('template-parts/general/social-icons', null, [
							'icon_location' => 'footer'
						]);?>

						<div class='copyright-text'>
							<?= $copyright_text;?>
						</div>
					</div>
					<div id='footer-contact-form' class='right'>
						<?php
						if ($footer_form_id > 0) {
							echo do_shortcode('[gravityform id="'.$footer_form_id.'" ajax="true"]');
						}
						?>
					</div>
				</div>
			</div>
		</div>

	</footer>

</div><!-- #page -->


<?php wp_footer(); ?>
</body>
</html>
