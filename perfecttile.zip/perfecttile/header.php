<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<?php wp_head(); ?>
	<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
	<div id="cover-page-layer"></div>
	<div id='header-site' class='page__header'>
		<div id='header__country'>
			<?php get_template_part('template-parts/header/select-languages');?>
			<?php get_template_part('template-parts/header/select-countries');?>
		</div>
		<div id='header__menu'>
			<div class='wrapper'>
				<?php get_template_part('template-parts/header/logo');?>
				<?php get_template_part('template-parts/header/nav-menu');?>

				<?php
				get_template_part('template-parts/general/social-icons', null, [
					'wrapper_class' => 'menu__social'
				]);
				?>

			</div>
		</div>
		<div id="header__top-mobile">
			<?php get_template_part('template-parts/header/logo');?>
			<div id='navbar-icon'>
				<div class='bar-inside'>
				</div>
			</div>
		</div>
		<div id="header__menu-mobile">
			<?php get_template_part('template-parts/header/logo');?>

			<?php
				get_template_part('template-parts/general/social-icons', null, [
					'wrapper_class' => 'menu__social'
				]);
			?>

			<?php get_template_part('template-parts/header/nav-menu');?>
		</div>
	</div>
</div>
	<main id="main" class="site-main">
