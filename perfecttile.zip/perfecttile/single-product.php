<?php

get_header();

while ( have_posts() ) :
    the_post();
    $product_fields = get_field('single_product_fields');
?>



<div class='page-body'>
	<?php
	get_template_part('template-parts/general/page-banner', null, [
        'url' => !empty($product_fields['banner']) ? $product_fields['banner']['sizes']['large'] : null
    ]);
	?>

    <div class='product'>
        <div class='product__general'>
            <div class='general__wrapper'>
                <div class='row justify-content-end align-items-center'>
                    <div class='col-12 col-md-4 image-introduce'>
                        <?php
                            get_template_part('template-parts/product/single/gallery', null, [
                                'gallery' => !empty($product_fields['gallery']) ? $product_fields['gallery'] : null
                            ]);
                        ?>
                    </div>
                    <div class='col-12 col-md-4 info-introduce'>
                        <?php
                            get_template_part('template-parts/product/single/info');
                        ?>
                    </div>
                    <div class='col-12 col-md-3 picture-360'>
                        <?php
                            get_template_part('template-parts/product/single/thumbnail-with-image-360-degree', null, [
                                'image_360_degree' => !empty($product_fields['image_360_deg']) ? $product_fields['image_360_deg'] : null
                            ]);
                        ?>
                    </div>
                </div>
            </div>
        </div>

        <?php
            get_template_part('template-parts/product/single/specifications', null, [
                'specifications' => !empty($product_fields['specifications']) ? $product_fields['specifications'] : null,
                'color_name' => !empty($product_fields['color_name']) ? $product_fields['color_name'] : null
            ]);

            echo '<div class="container mb-5">' ;
            the_content();
            echo '</div>';

            // Get related product that have same collection
            $current_product_ID = get_the_ID();
            $tax_collection = 'collection';

            $default_args = [
                'post__not_in' => [$current_product_ID]
            ];

            $current_terms = get_the_terms($current_product_ID, $tax_collection);
            $current_term_ids = !empty($current_terms) ? wp_list_pluck($current_terms, 'term_id') : [];

            if (!empty($current_term_ids)) {
                $default_args['products_by_collection'] = $current_term_ids;
            }

            get_template_part('template-parts/product/list', null, $default_args);
        ?>

        <?php
            get_template_part('template-parts/taxonomies/collection/related-collections');
        ?>

        <?php
            $product_general_secs = get_acf_option('product_general_sections');
            $sec_video_data = get_acf_flexible_content($product_general_secs, 'sec-video');

            get_template_part('template-parts/general/sec-video', null, $sec_video_data);
        ?>


    </div>
</div>

<?php
endwhile;

get_footer();
