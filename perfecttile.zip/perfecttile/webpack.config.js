const path = require('path');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const { WebpackManifestPlugin } = require('webpack-manifest-plugin');

module.exports = (env, argv) => {
  const isDev = argv.mode === 'development';

  return {
    entry: {
      main: path.join(__dirname, 'assets/js/main.js'),
    },
    externals: {
      jquery: 'jQuery',
    },
    output: {
      path: path.resolve(__dirname, 'dist/'),
      clean: true,
      filename: isDev ? 'js/[name].js' : 'js/[name].[contenthash].js',
      publicPath: isDev ? 'auto' : '/app/themes/perfecttile/dist/',
    },
    devServer: {
      host: '0.0.0.0',
      devMiddleware: {
        index: true,
        writeToDisk: true,
      },
      watchFiles: {
        paths: ['*.php', 'templates/**/*.php','template-parts/**/*.php'],
        options: {
          usePolling: false,
        },
      },
      allowedHosts: 'all',
      liveReload: true,
      compress: true,
      port: 9000,
      hot: true,
      headers: {
        'Access-Control-Allow-Origin': '*',
      },
    },
    plugins: [
      new MiniCssExtractPlugin({
        filename: isDev ? 'css/[name].css' : 'css/[name].[contenthash].css',
      }),
      new WebpackManifestPlugin(),
    ],
    optimization: {
      splitChunks: {
        chunks: 'initial',
        cacheGroups: {
          vendor: {
            test: /[\\/]node_modules[\\/]/,
            name: 'vendors',
            chunks: 'initial',
            priority: -10,
          },
          slickCarousel: {
            test: /[\\/]node_modules[\\/](slick-carousel)[\\/]/,
            priority: -5,
            chunks: 'all',
          },
        }
      }
    },
    module: {
      rules: [
        {
          test: /\.js$/,
          exclude: /(node_modules|bower_components)/,
          use: {
            loader: 'babel-loader',
            options: {
              presets: ['@babel/preset-env'],
              cacheDirectory: true,
            }
          }
        },
        {
          test: /\.css$/i,
          use: [
            MiniCssExtractPlugin.loader,
            // Translates CSS into CommonJS
            'css-loader',
          ],
        },
        {
          test: /\.s[ac]ss$/i,
          use: [
            MiniCssExtractPlugin.loader,
            // Translates CSS into CommonJS
            'css-loader',
            // Compiles Sass to CSS
            'sass-loader',
          ],
        },
      ],
    },
  }
};