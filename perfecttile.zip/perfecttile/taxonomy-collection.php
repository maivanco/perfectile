<?php
get_header();

$term = get_queried_object();
$extra_fields = get_field('tax_collection_fields', $term);
?>
<div class='page-body'>

    <?php
    get_template_part('template-parts/general/page-banner', null, [
        'url' =>  !empty($extra_fields['featured_image']) ? $extra_fields['featured_image']['sizes']['large'] : null,
        'alt' => $term->name
    ]);
    ?>

    <div class='collection'>
        <?php

        get_template_part('template-parts/taxonomies/collection/intro', null, [
            'term' => $term,
            'specifications' => $extra_fields['specifications']
        ]);

        get_template_part('template-parts/product/list', null, [
            'products_by_collection' => $term->term_id,
        ]);

        get_template_part('template-parts/taxonomies/collection/related-collections', null, [
            'exclude_term' => $term->term_id
        ]);

        ?>

    </div>
</div>
<?php
get_footer();