<?php
function register_taxonomy_collection() {

    $labels = array(
		'name'              => __( 'Collections', 'taxonomy general name', 'perfecttile' ),
		'singular_name'     => __( 'Collection', 'taxonomy singular name', 'perfecttile' ),
		'search_items'      => __( 'Search Collections', 'perfecttile' ),
		'all_items'         => __( 'All Collections', 'perfecttile' ),
		'view_item'         => __( 'View Collection', 'perfecttile' ),
		'parent_item'       => __( 'Parent Collection', 'perfecttile' ),
		'parent_item_colon' => __( 'Parent Collection:', 'perfecttile' ),
		'edit_item'         => __( 'Edit Collection', 'perfecttile' ),
		'update_item'       => __( 'Update Collection', 'perfecttile' ),
		'add_new_item'      => __( 'Add New Collection', 'perfecttile' ),
		'new_item_name'     => __( 'New Collection Name', 'perfecttile' ),
		'not_found'         => __( 'No Collections Found', 'perfecttile' ),
		'back_to_items'     => __( 'Back to Collections', 'perfecttile' ),
		'menu_name'         => __( 'Collections', 'perfecttile' )
	);

    $args = array(
       'labels'        => $labels,
       'public'       => true,
       'rewrite'      => true,
       'hierarchical' => true
   );

   register_taxonomy( 'collection', 'product', $args );
}
add_action( 'init', 'register_taxonomy_collection', 0 );