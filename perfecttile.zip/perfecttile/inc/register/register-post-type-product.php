<?php
/**
 * Register a custom post type called "product".
 *
 * @see get_post_type_labels() for label keys.
 */
function register_post_type_product() {
	$labels = array(
		'name'                  => _x( 'Products', 'Post type general name', 'perfecttile' ),
		'singular_name'         => _x( 'Product', 'Post type singular name', 'perfecttile' ),
		'menu_name'             => _x( 'Products', 'Admin Menu text', 'perfecttile' ),
		'name_admin_bar'        => _x( 'Product', 'Add New on Toolbar', 'perfecttile' ),
		'add_new'               => __( 'Add New', 'perfecttile' ),
		'add_new_item'          => __( 'Add New Product', 'perfecttile' ),
		'new_item'              => __( 'New Product', 'perfecttile' ),
		'edit_item'             => __( 'Edit Product', 'perfecttile' ),
		'view_item'             => __( 'View Product', 'perfecttile' ),
		'all_items'             => __( 'All Products', 'perfecttile' ),
		'search_items'          => __( 'Search Products', 'perfecttile' ),
		'parent_item_colon'     => __( 'Parent Products:', 'perfecttile' ),
		'not_found'             => __( 'No products found.', 'perfecttile' ),
		'not_found_in_trash'    => __( 'No products found in Trash.', 'perfecttile' ),
		'archives'              => _x( 'Product archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'perfecttile' ),
		'insert_into_item'      => _x( 'Insert into product', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'perfecttile' ),
		'uploaded_to_this_item' => _x( 'Uploaded to this product', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'perfecttile' ),
		'filter_items_list'     => _x( 'Filter products list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'perfecttile' ),
		'items_list_navigation' => _x( 'Products list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'perfecttile' ),
		'items_list'            => _x( 'Products list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'perfecttile' ),
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array('slug' => 'collections/%collection%'),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => null,
		'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt'),
		'menu_icon'			 => 'dashicons-tagcloud',
	);

	register_post_type('product', $args );
}

add_action( 'init', 'register_post_type_product' );