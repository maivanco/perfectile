<?php
if( function_exists('acf_add_options_page') ) {
    acf_add_options_page(array(
        'page_title'    => __('Website Settings', 'perfecttile'),
        'menu_title'    => __('Website Settings', 'perfecttile'),
        'menu_slug'     => 'theme-general-settings',
        'capability'    => 'edit_posts',
        'redirect'      => false
    ));
}

// Single Product - Specifications - Set up default value
function admin_acf_load_value( $value, $post_id, $field ) {
    //Only for add new page
    if ($field['name'] == 'single_product_fields_specifications' && $value === false ){
        $value = [
            [
                'field_63da3910f4cbd' => 'Overall Thickness',
                'field_63db5f8b39330' => 'Width'
            ],
            [
                'field_63da3910f4cbd' => 'Length',
                'field_63db5f8b39330' => 'Wear Layer Thickness'
            ],
            [
                'field_63da3910f4cbd' => 'GREENGUARD Gold Certified',
                'field_63db5f8b39330' => 'Edge Style'
            ],
            [
                'field_63da3910f4cbd' => 'Locking System',
                'field_63db5f8b39330' => 'Surface Texture'
            ],
            [
                'field_63da3910f4cbd' => 'Gloss',
                'field_63db5f8b39330' => '100% Waterproof'
            ],
            [
                'field_63da3910f4cbd' => 'Box Content',
                'field_63db5f8b39330' => 'Box Weight'
            ],
            [
                'field_63da3910f4cbd' => 'Residential Warranty',
                'field_63db5f8b39330' => 'Fire&Smoke Resistance'
            ]
        ];
    }
    return $value;
}

// Apply to all fields.
add_filter('acf/load_value/name=specifications', 'admin_acf_load_value', 10, 3);