<?php

function perfecttile_admin_scripts_and_styles( $hook ) {
    $needed_screens = ['post.php','toplevel_page_theme-general-settings'];
    if (!in_array($hook, $needed_screens) ) {
        return;
    }
    wp_enqueue_style( 'perfecttile-admin', ASSETS_URL . '/css/perfecttile-admin.css', array(), '1.0' );
}
add_action( 'admin_enqueue_scripts', 'perfecttile_admin_scripts_and_styles' );

function theme_remove_menus(){
    if(ENVIRONMENT !== 'local'){
        remove_menu_page( 'edit.php' ); // Removes the Posts menu item
        remove_menu_page( 'edit-comments.php' ); // Removes the Comments menu item
        remove_menu_page( 'users.php' );
        remove_menu_page( 'plugins.php' );
        remove_menu_page( 'edit.php?post_type=acf-field-group' );
    }
}
add_action( 'admin_menu', 'theme_remove_menus' );