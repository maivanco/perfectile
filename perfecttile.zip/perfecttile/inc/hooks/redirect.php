<?php
function custom_redirects() {

    if (ENVIRONMENT === 'local') {
        return true;
    }
    global $blog_id;
    $site_to_redirect = null;

    if ($blog_id == 1) {
        $site_to_redirect = get_home_url(1).'/fj/';
        wp_redirect($site_to_redirect);
        exit();
    }

    if ( is_front_page() ) {

        $homepage_id = get_acf_option('default_homepage');
        if (!empty($homepage_id)) {
            $site_to_redirect = get_permalink($homepage_id);
        } else {
            $pages = get_pages(array(
                'meta_key' => '_wp_page_template',
                'meta_value' => 'templates/page-wall-tiles.php'
            ));
            if (!empty($pages)) {
                $site_to_redirect = get_permalink($pages[0]->ID);
            }
        }
        wp_redirect($site_to_redirect);
		exit;

	}

}
add_action('template_redirect', 'custom_redirects');