<?php
// completely disable image size threshold
add_filter( 'big_image_size_threshold', '__return_false' );