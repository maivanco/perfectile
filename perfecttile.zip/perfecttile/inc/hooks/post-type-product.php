<?php
function replace_post_type_product_url( $permalink, $post ) {
    if ( 'product' == get_post_type( $post ) ) {
        $taxonomy_name = 'collection';
        $terms = get_the_terms($post->ID, $taxonomy_name);
        $term_slug = '';
        if (!$terms) {
            $terms = get_terms([
                'taxonomy' => $taxonomy_name
            ]);
        }
        if ($terms) {
            $term_slug = $terms[0]->slug;
        }
        $permalink = str_replace('%'.$taxonomy_name.'%', $term_slug, $permalink);
    }
    return $permalink;
}
add_filter( 'post_type_link', 'replace_post_type_product_url', 10, 2 );

add_action('init', 'customize_post_type_product_permalink');
function customize_post_type_product_permalink() {
    add_rewrite_rule('^collections/([^/]*)/([^/]*)/?', 'index.php?product=$matches[2]&collection=$matches[1]', 'top');
}