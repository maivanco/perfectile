<?php
get_header();

while ( have_posts() ) :
	the_post();
?>


    <div class='page-body'>
        <div class='body__head-banner'>
            <?php
                the_post_thumbnail('large');
            ?>
        </div>
        <div id='homepage'>
            <section class='homepage__head-side'>
                <div class='container'>
                    <div class='introduce-label'>
                        <span class="star-custom-animation">
                            <?php the_title();?>
                        </span>
                    </div>
                    <div class='introduce-paragraph'>
                        <?php the_content();?>
                    </div>
                </div>
            </section>

            <?php
                render_sections_of_page('home_sections', 'template-parts/front-page/');
            ?>
        </div>
    </div>
<?php
endwhile;

get_footer();
