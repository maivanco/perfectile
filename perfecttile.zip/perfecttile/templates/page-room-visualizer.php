<?php
/* Template Name: Page Room Visualizer */

get_header(); ?>
<div class="page-body">

    <?php
        if( have_rows('page_roomvo') ):
            while (have_rows('page_roomvo')) :
                the_row();
                if (get_row_layout() == 'sec-head-banner') {
                    get_template_part('template-parts/page-room-visualizer/'.get_row_layout());
                    break; // stop while loop
                }
            endwhile;
        endif;
    ?>

    <?php
    if (have_rows('page_roomvo') ):
        echo ' <div class="visualizer">';
        while ( have_rows('page_roomvo') ) :
            the_row();
            if (get_row_layout() != 'sec-head-banner') {
                get_template_part('template-parts/page-room-visualizer/'.get_row_layout());
            }
        endwhile;
        echo '</div>';
    endif;
    ?>
</div>

<?php
get_footer();
