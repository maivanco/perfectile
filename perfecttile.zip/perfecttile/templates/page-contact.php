<?php
/* Template Name: Page Contact */

get_header();

/* Start the Loop */
while ( have_posts() ) :
	the_post();

	get_template_part('template-parts/general/page-banner');

endwhile; // End of the loop.

get_footer();
