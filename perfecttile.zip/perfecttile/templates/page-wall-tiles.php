<?php
/* Template Name: Page Wall Tiles */

get_header(); ?>
<div class='page-body'>

    <?php get_template_part('template-parts/general/page-banner');?>

    <div class='about'>
        <?php
            render_sections_of_page('page_wall_tiles', 'template-parts/page-wall-tiles/');
        ?>
    </div>
</div>
<?php
get_footer();
