<?php
/* Template Name: Page Faq */

get_header(); ?>

<?php

while ( have_posts() ) :
	the_post();
    $faq_fields = get_field('page_faq');
?>
<div class='page-body'>

    <?php get_template_part('template-parts/general/page-banner');?>

    <section class='faq'>
        <div class='container'>
            <div class='row'>
                <div class='col-12 col-md-3 faq__logo-side'>
                    <?php
                    render_image([
                        'src' => !empty($faq_fields['image_title']) ? $faq_fields['image_title']['sizes']['large'] : null,
                        'alt' => $faq_fields['subtitle']
                    ]);
                    ?>
                    <div class='title'>
                        <?= $faq_fields['subtitle'];?>
                    </div>
                </div>
                <div class='col-12 col-md-9 faq__question-side'>
                    <?php
                        if (!empty($faq_fields['questions_with_answers'])):
                            echo '<ul class="questions-container">';
                            foreach($faq_fields['questions_with_answers'] as $row):
                    ?>
                            <li class='item'>
                                <div class='item__question'>
                                    <?= $row['question'];?>
                                    <div class='show-button'>
                                        <img src="<?= IMAGES_URL ?>/Perfectiles_icon_plus.png" alt="">
                                    </div>
                                </div>
                                <div class='item__answer'>
                                    <?= $row['answer'];?>
                                </div>
                            </li>
                    <?php
                            endforeach;
                            echo '</ul>';
                        endif;
                    ?>

                    </ul>
                </div>
            </div>
        </div>
    </section>
</div>
<?php
endwhile;

get_footer();
