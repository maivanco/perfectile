<?php
/* Template Name: Page Store Locator */

get_header(); ?>

<?php
/* Start the Loop */
while ( have_posts() ) :
	the_post();
?>

<div class="page-body">

    <?php get_template_part('template-parts/general/page-banner');?>

    <style>
        .mapMarkerIcon{
            display:none;
        }
        .storeLocator .form-inline {
            margin-top: 10px;
            margin-left: 25px;
            margin-right: 25px;
        }
    </style>

    <!--store script-->
    <?php the_field('google_map_script');?>

    <script src="https://webapp.cflflooring.com/storelocator-frontend/static/js/chunk.js"></script>
    <script src="https://webapp.cflflooring.com/storelocator-frontend/static/js/main.chunk.js"></script>
    <script src="https://webapp.cflflooring.com/storelocator-frontend/static/js/runtime-main.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&key=AIzaSyCC_4Dr2iOSMNdWa49Bk29mFNEmNMFEybc&libraries=geometry,drawing,places"></script>


</div>

<?php
endwhile; // End of the loop.
?>

<?php
get_footer();
