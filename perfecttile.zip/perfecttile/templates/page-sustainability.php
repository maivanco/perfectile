<?php
/* Template Name: Page Sustainability */

get_header(); ?>

<?php
while ( have_posts() ) :
	the_post();
?>

<div class="page-body">

    <?php get_template_part('template-parts/general/page-banner');?>

    <div class="sustainability">
        <?php
            if( have_rows('page_sustainability') ):
                while ( have_rows('page_sustainability') ) : the_row();
                    get_template_part('template-parts/page-sustainability/'.get_row_layout());
                endwhile;
            endif;
        ?>

    </div>
</div>

<?php
endwhile; // End of the loop.
?>

<?php
get_footer();
