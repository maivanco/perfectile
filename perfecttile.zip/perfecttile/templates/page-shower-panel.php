<?php
/* Template Name: Page Shower Panel */

get_header(); ?>
<div class='page-body'>

    <?php get_template_part('template-parts/general/page-banner');?>

    <div class='about'>
        <?php
            render_sections_of_page('page_show_panel', 'template-parts/page-show-panel/');
        ?>
    </div>
</div>
<?php
get_footer();
