<?php

define('ENVIRONMENT', getenv('ENVIRONMENT'));

define('THEME_URL', get_template_directory_uri().'/');
define('ASSETS_URL', get_template_directory_uri().'/assets/');
define('IMAGES_URL', get_template_directory_uri().'/assets/images');
define('VIDEO_URL', get_template_directory_uri().'/assets/video');
define('DIST_MANIFEST_PATH', get_template_directory() . '/dist/manifest.json');

function load_files_in_folder($folder_path){
	$folder_path .= substr($folder_path,-1) == '/' ? '' : '/';
	$folder_path .= '*.php';
	foreach(glob($folder_path) as $file_path){
		require_once $file_path;
	}
}
load_files_in_folder(get_template_directory().'/inc/hooks/');
load_files_in_folder(get_template_directory().'/inc/register/');



// This theme requires WordPress 5.3 or later.
if ( version_compare( $GLOBALS['wp_version'], '5.3', '<' ) ) {
	require get_template_directory() . '/inc/back-compat.php';
}

if ( ! function_exists( 'perfect_tile_setup' ) ) {
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 *
	 * @since Twenty Twenty-One 1.0
	 *
	 * @return void
	 */
	function perfect_tile_setup() {

		load_theme_textdomain( 'perfecttile', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		add_theme_support( 'title-tag' );

		/**
		 * Add post-formats support.
		 */
		add_theme_support(
			'post-formats',
			array(
				'link',
				'aside',
				'gallery',
				'image',
				'quote',
				'status',
				'video',
				'audio',
				'chat',
			)
		);

		register_nav_menus(
			array(
				'primary' => esc_html__( 'Primary menu', 'perfecttile' ),
				'footer'  => esc_html__( 'Secondary menu', 'perfecttile' ),
			)
		);

		add_theme_support(
			'html5',
			array(
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
				'navigation-widgets',
			)
		);

		add_theme_support( 'post-thumbnails' );

		// Remove feed icon link from legacy RSS widget.
		add_filter( 'rss_widget_feed_link', '__return_false' );
	}
}
add_action( 'after_setup_theme', 'perfect_tile_setup' );

function perfect_tile_scripts() {
	wp_deregister_script( 'jquery' );
    wp_register_script( 'jquery', includes_url( '/js/jquery/jquery.js' ), false, NULL, true );
    wp_enqueue_script( 'jquery' );

	if (is_singular('product')) {
		wp_enqueue_script('threesixty', 'https://cdn.jsdelivr.net/npm/@mladenilic/threesixty.js/dist/threesixty.js', [], false, true);
	}

	wp_enqueue_script('fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/js/fontawesome.min.js', ['jquery'], false, true);
	wp_enqueue_script('aos', 'https://unpkg.com/aos@2.3.1/dist/aos.js', ['jquery'], false, true);

	// Register your script first
	wp_enqueue_script( 'roomvo', 'https://cdn.roomvo.com/static/scripts/b2b/perfectile.js', array(), '1.0', true );

	if (ENVIRONMENT === 'local') {
		$base_url = 'http://localhost:9000';
		wp_enqueue_script('vendors', $base_url . '/js/vendors.js', [], false, true);
		wp_enqueue_style('vendors', $base_url . '/css/vendors.css', [], false);
		wp_enqueue_script('main', $base_url . '/js/main.js', ['jquery', 'vendors'], false, true);
		wp_enqueue_style('main', $base_url . '/css/main.css', ['vendors'], false);
	} else {
		$manifest_data = json_decode(file_get_contents(DIST_MANIFEST_PATH), true);
		wp_enqueue_script('vendors', network_site_url() . $manifest_data['vendors.js'], [], false, true);
		wp_enqueue_style('vendors', network_site_url() . $manifest_data['vendors.css'], [], false);
		wp_enqueue_script('main', network_site_url() . $manifest_data['main.js'], ['jquery', 'vendors'], false, true);
		wp_enqueue_style('main', network_site_url() . $manifest_data['main.css'], ['vendors'], false);
	}
}
add_action( 'wp_enqueue_scripts', 'perfect_tile_scripts' );

function add_async_attribute($tag, $handle) {
    if ('roomvo' === $handle) {
        $tag = str_replace( ' src', ' async src', $tag );
    }
    return $tag;
}
add_filter('script_loader_tag', 'add_async_attribute', 10, 2);

// Remove or unregister unused WordPress Image Sizes
function perfecttile_remove_custom_image_sizes() {
	remove_image_size('1536x1536');
	remove_image_size('2048x2048');
	remove_image_size('medium_large');
}
// Hook the function
add_filter('init', 'perfecttile_remove_custom_image_sizes', 99, 2);

function get_acf_option($field_name){
	return get_field($field_name, 'option');
}

function get_acf_flexible_content($flexible_content, $layout_name){

	if (empty($flexible_content)) {
		return [];
	}

	foreach($flexible_content as $index => $info){
		if($info['acf_fc_layout'] == $layout_name ){
			unset($info['acf_fc_layout']);
			return $info;
		}
	}
	return [];
}

function render_image($attrs = []) {
	$default_attrs = [
		'src' => null,
		'alt' => null
	];
	$attrs = array_merge($default_attrs, $attrs);
	if (empty($attrs['src'])) {
		return false;
	}

	$attrs_str = '';
	foreach ($attrs as $name => $val) {
		$val = $name == 'alt' && !is_null($val) ? strip_tags($val) : $val;
		$attrs_str .= ' '.$name.'="'.$val.'"';
	}

	echo '<img'.$attrs_str.' >';
}

function prepend_attribute($extraAttr, &$specs) {

    $tempAttr = $extraAttr;
    foreach ($specs as &$row) {

        $leftAttr = [
            'label' => $row['label'],
            'value' => $row['value']
        ];

        $rightAttr = [
            'label2' => $row['label2'],
            'value2' => $row['value2']
        ];

        $row['label'] = $tempAttr['label'];
        $row['value'] = $tempAttr['value'];

        $row['label2'] = $leftAttr['label'];
        $row['value2'] = $leftAttr['value'];

        $tempAttr = [
            'label' => $rightAttr['label2'],
            'value' => $rightAttr['value2']
        ];
    }

	if (!empty($tempAttr['label'])) {
		$specs[] = [
			'label' => $tempAttr['label'],
			'value' => $tempAttr['value'],
			'label2' => '',
			'value2' => '',
		];
	}
}

function replace_excerpt_label_for_post_type( $translated_text, $text, $domain ) {
    global $post;
    // Check if the text domain is 'default' and the original text is 'Excerpt'

    if ($post && 'product' === $post->post_type && 'default' === $domain && 'Excerpt' === $text ) {
        // Replace 'Excerpt' with your desired label
        $translated_text = __( 'Short description', 'perfecttile' );
    }
    return $translated_text;
}
add_filter( 'gettext', 'replace_excerpt_label_for_post_type', 10, 3 );

function render_section_id($sectionID){
	if (!isset($GLOBALS['perfectile_loaded_sections'])) {
		$GLOBALS['perfectile_loaded_sections'] = [];
	}
	$number_of_times_section_loaded = isset($GLOBALS['perfectile_loaded_sections'][$sectionID]) ? $GLOBALS['perfectile_loaded_sections'][$sectionID] + 1 : 1;
	//Assign or increase number of times section loaded
	$GLOBALS['perfectile_loaded_sections'][$sectionID] = $number_of_times_section_loaded;

	echo $sectionID.$number_of_times_section_loaded;
}

function render_sections_of_page($acf_field_name, $section_location){
	if (!have_rows($acf_field_name)) {
		return false;
	}

	while ( have_rows($acf_field_name) ) : the_row();
		$section_name = get_row_layout();
		if ($section_name == 'sec-general-sec') {
			$general_sec_name = get_sub_field('select_a_general_section');
			get_template_part('template-parts/general/'.$general_sec_name);
		} else {
			get_template_part($section_location.$section_name);
		}

	endwhile;
}