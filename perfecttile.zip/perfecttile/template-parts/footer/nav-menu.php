<?php
$footerMenu = get_acf_option('footer_menu');
if (empty($footerMenu)){
    return false;
}
?>
<ul class="anchor-popup">
    <?php
        foreach($footerMenu as $menuItem):
            $href = $menuItem['menu_item_type'] ==  'link_to_page' ? $menuItem['link_to_page'] : $menuItem['link_to_file'];
            $target = $menuItem['menu_item_type'] ==  'link_to_page' ? '_self'  : '_blank';
    ?>
    <li class='anchor-popup__item__wrapper'>
        <a class="anchor-popup__item" href="<?= $href?>" target="<?= $target?>">
            <span class='icon-side'>
                <?php echo $menuItem['icon']?>
            </span>
            <div class="title-side">
                <?php echo $menuItem['menu_item_title']?>
            </div>
        </a>
    </li>
    <?php endforeach;?>
</ul>