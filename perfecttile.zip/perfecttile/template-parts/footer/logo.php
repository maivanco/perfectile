<?php
$footerLogo = get_acf_option('footer_logo');
if (empty($footerLogo)) {
    return false;
}
?>
<a class="head-logo" href="<?= home_url();?>">
    <?php
        render_image([
            'src' => $footerLogo['sizes']['medium'],
            'alt' => $footerLogo['title']
        ]);
    ?>
</a>