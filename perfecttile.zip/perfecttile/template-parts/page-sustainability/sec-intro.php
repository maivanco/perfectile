<?php
    $sec_title = get_sub_field('section_title');
    $intro_image = get_sub_field('intro_image') ? get_sub_field('intro_image')['sizes']['medium'] : null
?>

<section class="sustainability__head">
    <div class="image-decoration">
        <img src="<?= IMAGES_URL ?>/Perfectiles_background_decoration.png" alt="">
    </div>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-12 col-md-6 title-side">
                <h1><?php echo $sec_title;?></h1>
            </div>
            <div class="col-12 col-md-6 image-side">
                <?php
                    render_image([
                        'src' => $intro_image
                    ]);
                ?>
            </div>
        </div>
    </div>
</section>