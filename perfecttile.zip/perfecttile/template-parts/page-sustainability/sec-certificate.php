<?php
    $thumb = get_sub_field('thumbnail') ? get_sub_field('thumbnail')['sizes']['medium'] : null;
    $cert_img = get_sub_field('cert_image') ? get_sub_field('cert_image')['sizes']['medium'] : null;
?>
<section class="sustainability__introduce">
    <div class="container">
        <div class="introduce__wrapper">
            <div class="image-side">
                <?php
                render_image([
                    'src' => $thumb
                ]);
                ?>
            </div>
            <div class="content-side">
                <div class="wrapper">
                    <div class="top">
                        <div class="left-cont">
                            <?php the_sub_field('top_content')?>
                        </div>
                        <div class="cert" data-aos="zoom-in">
                            <?php
                                render_image([
                                    'src' => $cert_img
                                ]);
                            ?>
                        </div>
                    </div>
                    <?php the_sub_field('bottom_content')?>
                </div>
            </div>
        </div>
    </div>
    <div class="background-decoration"></div>
</section>