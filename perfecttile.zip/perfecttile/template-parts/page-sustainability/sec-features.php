<?php
    $features = get_sub_field('features');
    if (empty($features)) {
        return false;
    }
?>

<section class="sustainability__feature">
    <div class="container">
        <ul class="feature__wrapper">
            <?php
                $countOrder = 0;
                foreach ($features as $item) :
                    $countOrder++;
            ?>
                <li
                    class="feature__item <?php echo $item['content_type'] == 'image' ? 'only-image' : '' ?>"
                    data-aos="fade-left"
                    data-aos-delay="<?=$countOrder?>00"
                >
                    <?php
                        if ($item['content_type'] == 'image') {
                            render_image([
                                'src' => $item['image'] ? $item['image']['sizes']['medium'] : null
                            ]);

                        }elseif ($item['content_type'] == 'content') {
                    ?>
                            <img class="icon" src="<?= $item['content']['icon']['sizes']['thumbnail'] ?>" alt="">

                            <h3 class="title">
                                <?= $item['content']['title']?>
                            </h3>
                            <div class="content">
                                <?= $item['content']['desc']?>
                            </div>
                    <?php
                        }
                    ?>
                </li>
            <?php endforeach;?>
        </ul>
    </div>
</section>