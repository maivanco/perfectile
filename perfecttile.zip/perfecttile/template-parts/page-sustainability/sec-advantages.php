<?php
$advantages = get_sub_field('advantages');

if (empty($advantages)) {
    return false;
}
?>

<section class="sustainability__advantage">
    <div class="container">
        <ul class="advantage__wrapper">
            <?php
                $block_counter = 0;
                foreach ($advantages as $item) :
                    $block_counter++;
            ?>
                <li data-aos="fade-up" data-aos-delay="<?=$block_counter?>00" class="item__wrapper">
                    <div class="item__advantage text-center">
                        <?php
                            render_image([
                                'src' => !empty($item['icon']) ? $item['icon']['sizes']['medium'] : null,
                            ]);
                        ?>
                        <h6 class="lbl"><?= $item['label']?></h6>
                    </div>
                </li>
            <?php endforeach;?>
        </ul>
    </div>
</section>