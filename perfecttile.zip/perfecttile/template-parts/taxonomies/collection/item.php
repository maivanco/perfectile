<?php
    $current_term = $args['term'];
    $term_link = get_term_link($current_term->term_id);

    $extra_fields = get_field('tax_collection_fields', $current_term);

    $specs = !empty($extra_fields['specifications']) ? $extra_fields['specifications'] : [];
?>

<div class="collections__carousel-item">
    <div class="image-main">
        <?php
            render_image([
                'src' => !empty($extra_fields['thumbnail']) ? $extra_fields['thumbnail']['sizes']['thumbnail'] : null
            ]);
        ?>
    </div>
    <div class="content">
        <?= $current_term->name ?>
    </div>
    <div class="info-side">
        <div class="name-collection">
            <?= $current_term->name ?>
        </div>
        <?php
        if(!empty($specs)):
            echo '<div class="specification">';
                echo '<table class="table-container"><tbody>';
            foreach($specs as $row):

        ?>
                <tr>
                    <td class="criteria"><?= $row['label'];?></td>
                    <td class="value"><?= $row['value'];?></td>
                </tr>
        <?php
            endforeach;
            echo '</tbody></table>';
            echo '</div>';
        endif;
        ?>
        <a class="learn-button red" href="<?= $term_link;?>">
            <?= get_acf_option('learn_more_button_text') ?? __('Learn more', 'perfecttile');?>
        </a>
    </div>
</div>