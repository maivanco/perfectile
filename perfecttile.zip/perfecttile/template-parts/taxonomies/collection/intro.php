<?php
$term = $args['term'];
$specifications = $args['specifications'];
?>

<section class='collection__general'>
    <div class='general__background'>

    </div>
    <div class='general__introduce'>
        <div class="name">
            <?= $term->name;?>
        </div>
        <div class="content">
            <?= $term->description?>
        </div>
    </div>
    <div class='general__specification'>
        <div class="wrapper">
            <?php
                if(!empty($specifications)):
                    echo '<table class="specification__table">';
                    foreach($specifications as $row):
            ?>
                        <tr>
                            <td class='criteria'><?= $row['label'] ?></td>
                            <td class='value'><?= $row['value'] ?></td>
                        </tr>
            <?php
                    endforeach;
                    echo '</table>';
                endif;
            ?>
        </div>
    </div>
</section>