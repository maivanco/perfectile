<?php
    $current_term = isset($args['term']) ? $args['term'] : get_queried_object();

    $request_params = [
        'taxonomy' => 'collection',
        'hide_empty' => true,
    ];

    if (!empty($args['exclude_term'])) {
        $request_params['exclude'] = is_array($args['exclude_term']) ? $args['exclude_term'] : [$args['exclude_term']];
    }

    $related_terms = get_terms($request_params);

    if (empty($related_terms)) {
        return false;
    }

    $collection_label = get_acf_option('product_collection_label') ?? __('Collections', 'perfecttile');
?>

<div class='other-collection'>
    <div class='container'>
        <div class='wrapper'>
            <div class='title'>
                <?= $collection_label?>
            </div>
            <div class='collections-side-container'>
                <?php
                    foreach ($related_terms as $term) {
                        get_template_part('template-parts/taxonomies/collection/item', null, [
                            'term' => $term
                        ]);
                    }
                ?>
            </div>
        </div>
    </div>
</div>