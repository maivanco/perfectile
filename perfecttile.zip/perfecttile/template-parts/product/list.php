<?php
/**
 * This section was loaded by 2 templates: taxonomy-collection & single-product
 */
$section_title = isset($args['section_title']) ? $args['section_title'] : '';
$other_colors_label = get_acf_option('other_colors_label') ?? __('Other colors', 'perfecttile');
$qpr_args = [
    'post_type' => 'product',
    'posts_per_page' => get_option('posts_per_page')
];

if (!empty($args['products_by_collection'])) {
    $qpr_args['tax_query'] = [
        [
            'taxonomy' => 'collection',
			'field'    => 'term_id',
			'terms'    => $args['products_by_collection']
        ]
    ];
}

if (isset($args['post__not_in'])) {
    $qpr_args['post__not_in'] = $args['post__not_in'];
}

$products = new WP_Query($qpr_args);

if (!$products->have_posts()) {
    return false;
}

?>

<section class='other-colors__show'>
    <div class='container'>
        <div class='wrapper'>

            <?php if(is_singular('product')):?>

                <div class="show__title"><?php echo $other_colors_label ?></div>

            <?php endif;?>

            <div class='show__background'>
                <img src="<?= IMAGES_URL ?>/Perfectiles_background_decoration.png" alt="">
            </div>
            <div class='row justify-content-center top-content-layer show__items-container'>
                <?php
                    while($products->have_posts()):
                        $products->the_post();
                ?>
                        <div class='col-12 col-sm-6 col-md-3'>
                            <?php get_template_part('template-parts/product/item'); ?>
                        </div>
                <?php
                    endwhile;
                    wp_reset_postdata();
                ?>
            </div>
        </div>
    </div>
</section>