<a class='show__item' href='<?php the_permalink();?>'>
    <?php
        the_post_thumbnail('medium');
    ?>
    <div class='name'>
        <?php the_title();?>
    </div>
</a>