<?php
if (empty($args['gallery'])) {
    return false;
}
?>
<div class="carousel-introduce-container">
    <?php foreach($args['gallery'] as $img):?>
        <div class="item">
            <?php render_image([
                'src' => $img['sizes']['medium'],
                'alt' => $img['title']
            ])?>
        </div>
    <?php endforeach;?>
</div>
<!-- <a href="javascript:void(0)" class="view-text roomvo-stimr" data-roomvo-product-code="<?= str_replace(home_url(),'',get_permalink());?>">
    <?= __('View in my room', 'perfecttile')?>
</a> -->