<?php
    $get_in_touch_label = get_acf_option('get_in_touch_label') ?? __('Get in touch!', 'perfecttile');
?>
<h3 class="code"><?php the_title();?></h3>
<p class="name-collection"><?php the_terms(get_the_ID(), 'collection', '');?></p>
<div class="content"><?php the_excerpt();?></div>
<a href='#footer-contact-form' class="get-in-touch scroll-to-div"><?= $get_in_touch_label ?></a>
