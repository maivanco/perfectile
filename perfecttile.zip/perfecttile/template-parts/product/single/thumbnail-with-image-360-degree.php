
<?php
$threesixtyAttributes = !empty($args['image_360_degree']) ? 'data-bs-toggle="modal" data-bs-target="#product360ImageModal"' : '';
$threesixtyClass = !empty($args['image_360_degree']) ? 'show-360-degree-image' : '';
?>

<a href="javascript:void(0)"  class="d-block main-image <?= $threesixtyClass?>" <?= $threesixtyAttributes?>>

    <?php the_post_thumbnail('medium');?>

    <?php if(!empty($args['image_360_degree'])):?>

        <span class="image-text-360">
            <img src="<?= IMAGES_URL ?>/Perfectiles_image_360_deg.png" alt="">
        </span>

    <?php endif;?>
</a>
<div class='background-decoration'></div>

<?php
if(!empty($args['image_360_degree'])):
    $images = [];
    $default_sizes = [
        'width' => $args['image_360_degree'][0]['sizes']['medium-width'],
        'height' => $args['image_360_degree'][0]['sizes']['medium-height']
    ];
    foreach ($args['image_360_degree'] as $img) {
        $images[] = $img['sizes']['medium'];
    }
?>

<!-- Modal -->
<div class="modal fade" id="product360ImageModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div id="productThreesixty" class="mx-auto"></div>
        </div>
        </div>
    </div>
</div>

<script>
    //Show 360 deg image when a user clicks to the product thumbnail
    let product360ImageModal = document.getElementById('product360ImageModal');
    product360ImageModal.addEventListener('shown.bs.modal', function (event) {
        let threesixtyEl = document.getElementById('productThreesixty');
        const threesixty = new ThreeSixty(threesixtyEl, {
            image: <?= json_encode($images);?>,
            width:<?= $default_sizes['width']?>,
            height:<?= $default_sizes['height']?>
        });
        threesixty.play(false, 1);
    });
</script>

<?php endif;?>

