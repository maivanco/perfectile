<?php
if (empty($args['specifications'])) {
    return false;
}
//Prepend an attribute into specifications - Color Name
prepend_attribute([
    'label' => __('Color Name', 'perfecttile'),
    'value' => $args['color_name']
], $args['specifications']);

?>
<div class='product__specification'>
    <div class='specification__decoration'></div>
    <div class='container'>
        <div class='specification__wrapper'>
            <table class='table-specification'>
                <tbody>
                <?php foreach($args['specifications'] as $row):?>
                    <tr>
                        <td class='criteria <?= empty($row['label']) ? 'empty' : ''?>'><?= $row['label'] ?></td>
                        <td class='value <?= empty($row['value']) ? 'empty' : ''?>'><?= $row['value'] ?></td>
                        <td class='criteria <?= empty($row['label2']) ? 'empty' : ''?>'><?= $row['label2'] ?></td>
                        <td class='value <?= empty($row['value2']) ? 'empty' : ''?>'><?= $row['value2'] ?></td>
                    </tr>
                <?php endforeach;?>
                </tbody>
            </table>
            <table class='table-specification mobile-table'>
                <tbody>
                <?php foreach($args['specifications'] as $row):?>
                    <tr>
                        <td class='criteria <?= empty($row['label']) ? 'empty' : ''?>'><?= $row['label'] ?></td>
                        <td class='value <?= empty($row['value']) ? 'empty' : ''?>'><?= $row['value'] ?></td>
                    </tr>
                    <tr>
                        <td class='criteria <?= empty($row['label2']) ? 'empty' : ''?>'><?= $row['label2'] ?></td>
                        <td class='value <?= empty($row['value2']) ? 'empty' : ''?>'><?= $row['value2'] ?></td>
                    </tr>
                <?php endforeach;?>
                </tbody>
            </table>
        </div>
    </div>
</div>