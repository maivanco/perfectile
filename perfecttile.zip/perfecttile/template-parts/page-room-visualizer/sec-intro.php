<section class="visualizer__introduce">
    <div class='container'>
        <div class="wrapper">
            <div class="main-content">
                <?php the_sub_field('top_content')?>
            </div>

            <div class="sub-content">
                <?php the_sub_field('bottom_content')?>
            </div>

        </div>
    </div>
</section>