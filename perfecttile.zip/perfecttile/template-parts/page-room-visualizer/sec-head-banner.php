<?php
    $banner_info = get_sub_field('banner_image');
    $thumbnail_info = get_sub_field('thumbnail');
    $button_text = get_sub_field('button_text');
?>
<section class="body__head-banner">
    <?php
    render_image([
        'src' => !empty($banner_info) ? $banner_info['sizes']['large'] : null
    ]);
    ?>
    <div class="roomvo-side">
        <?php
            render_image([
                'src' => !empty($thumbnail_info) ? $thumbnail_info['sizes']['medium'] : null
            ]);
        ?>

        <?php
            if ($button_text) {
                echo '<a href="#">'.$button_text.'</a>';
            }
        ?>

    </div>
</section>