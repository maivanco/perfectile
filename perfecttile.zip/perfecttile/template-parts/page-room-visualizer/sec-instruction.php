<?php
$steps = get_sub_field('steps');
if (empty($steps)) {
    return false;
}
?>
<section class="visualizer__instruction">
    <div class="container">
        <div class="wrapper">
            <ul class="instruction__step">
                <?php
                    $countInstruction = 0;
                    foreach ($steps as $step):
                    $countInstruction++;
                ?>
                <li class="step__item">
                    <div class="image-description" data-aos="<?= $countInstruction%2==0 ? "flip-left": "flip-right" ?>" data-aos-duration="600">
                        <?php render_image([
                            'src' => !empty($step['thumbnail']) ? $step['thumbnail']['sizes']['medium'] : null,
                            'alt' => $step['title']
                        ])?>
                    </div>
                    <div class="content-description">
                        <p class="title"><?= $step['step_label']?></p>
                        <h3 class="action">
                            <?= $step['title']?>
                        </h3>
                        <p class="content">
                            <?= $step['desc']?>
                        </p>
                    </div>
                </li>
                <?php endforeach;?>
            </ul>
        </div>
    </div>
</section>