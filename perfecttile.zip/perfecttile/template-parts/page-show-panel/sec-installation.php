<section id="<?php render_section_id('about__installation');?>" class='about__installation'>
    <div class='container'>
        <div class='installation__wrapper'>
            <div class='installation__image-decoration'>
                <img src="<?= IMAGES_URL ?>/Perfectiles_background_decoration.png" alt="">
            </div>
            <h1 class='installation__head-title top-content-layer'><?= get_sub_field('section_title')?></h1>
            <?php
                $content_blocks = get_sub_field('content_blocks');
                if(!empty($content_blocks)):
                    echo ' <div class="installation__container">';
                    $block_counter = 0;
                    foreach($content_blocks as $block):
                        $block_counter++;
            ?>
                        <div class="installation__each-item <?= fmod($block_counter, 2) == 1 ? 'left' : '' ?>">
                            <div class='content-introduce'>
                                <h3 class='title'>
                                   <?= $block['title'];?>
                                </h3>
                                <div class='content'>
                                    <?= $block['desc'];?>
                                </div>
                            </div>
                            <div class='image-introduce'>
                                <?php
                                    render_image([
                                        'src' => $block['thumbnail']['sizes']['medium'],
                                    ]);
                                ?>
                            </div>
                        </div>
            <?php
                    endforeach;
                    echo '</div>';
                endif;
            ?>
        </div>
    </div>
</section>