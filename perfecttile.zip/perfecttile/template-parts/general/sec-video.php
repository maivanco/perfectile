<?php
    $poster = !empty($args['poster']) ? $args['poster']['sizes']['large'] : '';
    $url = isset($args['video']) ? $args['video'] : '';
    if (empty($url)) {
        return false;
    }
?>
<div class="section-video">
    <video class="main-video" poster="<?= $poster ?>" controls>
        <source src="<?= $url?>" type="video/mp4">
    </video>
    <div class="icon-play">
        <i class="fa-solid fa-circle-play"></i>
    </div>
</div>