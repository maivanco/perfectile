<?php
$social_media_icons = get_acf_option('social_media_icons', 'option');

if (empty($social_media_icons)) {
    return false;
}
$default_args = [
    'icon_location' => 'header',
    'wrapper_class' => '',
];
$args = isset($args) && !empty($args) ? array_merge($default_args, $args) : $default_args;


echo '<div class="social-media '.$args['wrapper_class'].'">';
foreach ($social_media_icons as $row) {
    if ($args['icon_location'] == 'header'){
        $icon_url = !empty($row['header_icon']) ? $row['header_icon']['sizes']['medium'] : '';
    }else { //Footer location
        $icon_url = !empty($row['footer_icon']) ? $row['footer_icon']['sizes']['medium'] : '';
    }

    if ($icon_url != '') {
        echo '<a href="'.$row['url'].'" target="_blank" class="item '.$row['custom_class'].'">';
            echo '<img src="'.$icon_url.'" alt="">';
        echo '</a>';
    }
}
echo '</div>';