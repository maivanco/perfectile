<?php
   //Current support for post/page & taxonomy
   $img_url = isset($args['url']) ? $args['url'] : null;
   $alt = isset($args['alt']) ? $args['alt'] : get_the_title();

   if ( is_singular('page') || is_singular('post') ) {
        $img_url = get_the_post_thumbnail_url(get_the_ID(), 'large');
   }
?>

<section class="body__head-banner">
    <?php
        render_image([
            'src' => $img_url,
            'alt' => $alt
        ]);
    ?>
</section>