<?php
    $general_sections = get_acf_option('general_sections');
    $sec_roomvo = get_acf_flexible_content($general_sections, 'sec-roomvo');

    $title = $sec_roomvo['title'];
    $roomvo_img = !empty($sec_roomvo['roomvo_image']) ? $sec_roomvo['roomvo_image']['sizes']['large'] : null;

?>
<section id="<?= render_section_id('sec__roomvo')?>" class='sec__roomvo'>
    <div class='roomvo__base'>
        <div class='container'>
            <div class='content'>
                <?= $title?>
            </div>
            <div class='image-roomvo call-roomvo-popup'>
                <a href="javascript: ffViz.startStandalone();">
                    <?php
                        render_image([
                            'src' => $roomvo_img,
                            'alt' => $title
                        ]);
                    ?>
                </a>
            </div>
        </div>
    </div>
    <div class='roomvo__background'></div>
</section>