<?php
    $video_tmb = get_sub_field('video_thumbnail') ? get_sub_field('video_thumbnail')['sizes']['large'] : null;
?>
<section id="<?php render_section_id('about__feature');?>" class='about__feature'>
    <div class='feature__background'></div>
    <div class='feature__image-decoration'>
        <img src='<?= IMAGES_URL ?>/Perfectiles_background_decoration.png'>
    </div>
    <div class='feature__head-title'>
        <div class='container text'>
            <?= get_sub_field('section_title');?>
        </div>
    </div>
    <div class='feature__video-introduce'>
        <video controls src="<?= get_sub_field('video');?>" poster="<?= $video_tmb;?>">
            <source src="<?= get_sub_field('video');?>" type="">
        </video>
    </div>
</section>