<?php
    $display_collections = get_sub_field('display_collections');
?>
<section id="<?php render_section_id('about__collections');?>" class="about__collections">
    <div class="container">
        <div class="collections__title-side star-animation-container">
            <h1 class="title star-rotate-animation"><?= get_sub_field('section_title')?></h1>
            <div class="content after-start-rotate" data-aos="flip-up" data-aos-duration="600">
                <?= nl2br(get_sub_field('desc'));?>
            </div>
        </div>
        <?php
        if(!empty($display_collections)){
            echo '<div class="collections__carousel">';
                echo '<div class="collections__carousel-container">';
                foreach($display_collections as $collection):
                    get_template_part('template-parts/taxonomies/collection/item', null,[
                        'term' => $collection
                    ]);
                endforeach;
                echo '</div>';
            echo '</div>';
        }
        ?>
    </div>
</section>