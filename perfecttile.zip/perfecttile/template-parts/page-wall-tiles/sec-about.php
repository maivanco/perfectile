<section id="<?php render_section_id('about__install');?>" class="about__install">
    <div class='install__background'></div>
    <div class='install__content-side'>
        <div class='row'>
            <div class='col-12 col-lg-7 left'>
                <div class='head-text star-custom-animation'>
                    <?= get_sub_field('section_title')?>
                </div>
                <div class='content'>
                    <?= get_sub_field('content')?>
                </div>
            </div>
            <div class='col-12 col-lg-5 right'>
                <div class='image-represent'>
                    <?php
                        render_image([
                            'src' => get_sub_field('thumbnail') ? get_sub_field('thumbnail')['sizes']['large'] : null
                        ]);
                    ?>
                </div>
            </div>
        </div>
    </div>
</section>