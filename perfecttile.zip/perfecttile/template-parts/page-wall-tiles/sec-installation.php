<?php
    $content_blocks = get_sub_field('content_blocks');
?>

<section id="<?php render_section_id('about__installation');?>" class='about__installation'>
    <div class='container'>
        <aside class='installation__wrapper'>
            <div class='installation__image-decoration'>
                <img src="<?= IMAGES_URL ?>/Perfectiles_background_decoration.png" alt="">
            </div>
            <h1 class='installation__head-title top-content-layer'><?= get_sub_field('section_title')?></h1>
            <h3 class="installation__construction-title"><?= get_sub_field('subtitle')?></h3>

            <div class="installation__construction-content">
                <?= get_sub_field('short_description');?>
            </div>
            <?php
                $featured_items = get_sub_field('featured_items');
                if(!empty($featured_items)):
                    $counter = 0;
                    echo '<div class="installation__special-item"><div class="row">';
                    foreach($featured_items as $row):
                        $counter++;
            ?>
                <div class="<?= $counter == 1 ? 'col-12 col-lg-6 item double' : 'col-6 col-lg-3 item' ?>">
                    <?php
                        render_image([
                            'src' => $row['thumbnail'] ? $row['thumbnail']['sizes']['medium'] : null,
                            'alt' => $row['title']
                        ]);
                    ?>
                    <div class="name-case">
                        <?= $row['title']; ?>
                    </div>
                </div>

            <?php
                endforeach;
                echo '</div></div><!--installation__special-item-->';
            endif;
            ?>


            <?php
                if(!empty($content_blocks)):
                    echo ' <div class="installation__container">';
                    $block_counter = 0;
                    foreach($content_blocks as $block):
                        $block_counter++;
            ?>
                        <div class="installation__each-item">
                            <div class='content-introduce'>
                                <h3 class='title'>
                                   <?= $block['title'];?>
                                </h3>
                                <div class='content'>
                                   <?= $block['desc'];?>
                                </div>
                            </div>
                            <div class='image-introduce'>
                                <?php
                                    render_image([
                                        'src' => $block['thumbnail'] ? $block['thumbnail']['sizes']['medium'] : null
                                    ]);
                                ?>
                            </div>
                        </div>
            <?php
                    endforeach;
                    echo '</div>';
                endif;
            ?>
        </aside>
    </div>
</section>