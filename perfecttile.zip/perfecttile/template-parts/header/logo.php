<?php
$headerLogo = get_acf_option('header_logo');
if(!empty($headerLogo)):
    echo '<a href="'.home_url().'" class="menu__logo">';
        render_image([
            'src' => $headerLogo['sizes']['medium'],
            'alt' => str_replace('_',' ',$headerLogo['title'])
        ]);
    echo '</a>';
endif;