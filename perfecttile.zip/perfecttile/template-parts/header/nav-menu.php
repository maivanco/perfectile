<div class='menu__navbar'>
    <?php
        wp_nav_menu([
            'theme_location' => 'primary',
            'container_id' => '',
            'container' => 'nav',
            'menu_id' => 'primary-menu', // id of <ul>
            'menu_class' => '', //class of <ul>
            "walker"  => new Header_Menu_Walker()
        ]);
    ?>
</div>