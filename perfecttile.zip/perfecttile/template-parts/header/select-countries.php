<?php
$publicSites = get_sites(['public' => 1]);
if (empty($publicSites)) {
    return false;
}
$currentBlogID = get_current_blog_id();

?>

<div class='country__select'>
    <img src="<?php echo IMAGES_URL?>/Perfectiles_icon_location.png" alt="" class='icon-location'>
    <select class="countries">
        <?php
            foreach($publicSites as $site):
                $site = get_blog_details($site->blog_id);
                $attrOptionSelected = $currentBlogID == (int) $site->blog_id ? 'selected="selected"' : '';
                echo '<option '.$attrOptionSelected.' value="'.$site->home.'">'.$site->blogname.'</option>';
            endforeach;
        ?>
    </select>
    <div class='arrow-container'>
        <img src="<?php echo IMAGES_URL ?>/Perfectiles_icon_arrow_down_white.png" alt="">
    </div>
</div>