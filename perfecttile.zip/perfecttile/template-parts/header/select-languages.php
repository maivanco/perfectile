<div class='country__language'>
    <img src="<?php echo IMAGES_URL ?>/Perfectiles_icon_globe.png" alt="" class='icon-globe'>
    <select>
        <option value="english">English</option>

    </select>
    <div class='arrow-container'>
        <img src="<?php echo IMAGES_URL ?>/Perfectiles_icon_arrow_down_white.png" alt="">
    </div>
</div>