<?php
    $collections = get_sub_field('collections');
    if(empty($collections)){
        return false;
    }

?>
<section class='homepage__waterproof'>
    <?php foreach($collections as $collection):?>
    <div class='item'>
        <div class='item__background-image'>
            <?php
                render_image([
                    'src' => $collection['thumbnail']['sizes']['large'],
                    'alt' => $collection['bottom_title']
                ]);
            ?>
        </div>
        <div class='item__hover-layer'>
            <div class='inner'>
                <img src="<?= IMAGES_URL ?>/Perfectiles_homepage_waterproof_layer.png" alt="" class='background-image'>
                <h1 class='title'><?php echo $collection['hover_box']['title']?></h1>
                <div class='content'>
                    <?php echo $collection['hover_box']['description']?>
                </div>
                <a class='learn-button' href="<?php echo $collection['hover_box']['button_link']?>"><?php echo $collection['hover_box']['button_text']?></a>
            </div>
        </div>
        <div class='item__title-block'>
            <?php echo $collection['bottom_title'];?>
        </div>
    </div>
    <?php endforeach;?>
</section>



