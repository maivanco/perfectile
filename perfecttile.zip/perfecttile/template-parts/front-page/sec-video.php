<?php
    $poster_url = get_sub_field('poster_url');
    $video_url = get_sub_field('video_url');
?>
<section class='section-video'>
    <video class='main-video' poster="<?= $poster_url ?>"  controls>
        <source src='<?= $video_url;?>' type="video/mp4">
    </video>
    <div class='icon-play'>
        <i class="fa-solid fa-circle-play"></i>
    </div>
</section>