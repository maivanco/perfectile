<?php
    $sec_title = get_sub_field('section_title');
    $features = get_sub_field('features');

?>
<div class='homepage__compare'>
    <div class='container'>
        <h3 class='compare__title'><?php echo $sec_title;?></h3>
        <?php if(!empty($features)):?>
        <div class='compare__table'>
            <table class='table__container'>
                <?php
                    foreach($features as $index => $row):
                        $is_first_row = $index == 0 ? true : false;

                ?>
                <tr class='table__row'>
                    <td class='col-one'>
                        <?php echo $row['feature_title']?>
                    </td>
                    <?php
                        if(!empty($row['brand_comparison'])):
                            $classes_order = ['two','three'];
                            foreach($row['brand_comparison'] as $brand_index => $brand):
                    ?>
                            <td class='col-<?php echo $classes_order[$brand_index]?> <?php echo $is_first_row ? 'first' : '' ?>'>
                                <?php echo $is_first_row ? '<div class="title-col">'.$brand['brand_name'].'</div>' : '' ?>

                                <?php if($brand['has_this_feature']):?>
                                    <img src="<?= IMAGES_URL ?>/Perfectiles_special-tick_icon.png" alt="">
                                <?php else:?>
                                    <div class='gray-subtract'></div>
                                <?php endif;?>

                            </td>
                    <?php
                            endforeach;
                        endif;
                    ?>
                </tr>
                <?php endforeach;?>
            </table>
        </div>
        <?php
        endif;
        ?>
    </div>
</div>