// Import all of Bootstrap's JS
import * as bootstrap from 'bootstrap';
import $ from 'jquery';
import '../sass/main.scss';

// if (module.hot) {
//   module.hot.accept('./main.js');
// }

const initCollectionsCarouselContainer = async () => {

  await import('slick-carousel');
  $('.collections__carousel-container').slick(
    {
      infinite: true,
      slidesToShow: 2,
      slidesToScroll: 1,
      arrows: true,
      prevArrow : '<button type="button" class="slick-arrow slick-prev"><i class="fa-solid fa-angle-left"></i></button>',
      nextArrow : '<button type="button" class="slick-arrow slick-next"><i class="fa-solid fa-angle-right"></i></button>',
      dots: false,
      responsive: [
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true,
        }
      },
      ]
    }
  );
  $('.carousel-introduce-container').slick(
    {
      infinite: true,
      slidesToShow: 1,
      slidesToScroll: 1,
      dots: false,
      prevArrow: '<button type="button" class="slick-arrow slick-prev"></button>',
      nextArrow: '<button type="button" class="slick-arrow slick-next"></button>',
    }
  );

  $('#header__menu').parents().css('overflow','visible')
  $('.faq  .item__question').on('click',function(e) {
    e.preventDefault();
    $('.faq .questions-container .item').each(function(){
      $(this).removeClass('active');
      $(this).children('.item__answer').slideUp(300);
      console.log('Testing',$(this));
    })
    $(this).parents('.item').addClass('active').children('.item__answer').slideDown(300);

  });
  $('.faq .item:first-child').addClass('active')
  $('.faq .item:first-child .item__answer').slideDown(300);
}

const main = async () => {

  initCollectionsCarouselContainer();
  $('a[href="#"]').on('click',function(e){
    e.preventDefault();
  })
  $('#header__menu #primary-menu .menu-item.menu-item-has-children').on('mouseenter',function(){
    $('#header__menu #primary-menu .menu-item').addClass('darker');
    $('#header__menu #primary-menu .menu-item .menu-item').removeClass('darker');
    $(this).removeClass('darker').addClass('hover');
  }).on('mouseleave',function(){
    $(this).removeClass('hover');
    $('#header__menu #primary-menu .menu-item').removeClass('darker')
  })
  // Set padding top for body

  var heightMenu = $('#header__country').height() + $('#header__menu').height();
  var heightMenuMobile = $('#header__country').height() + $('#header__top-mobile').height();
  $('#main').css({
    'paddingTop': `${window.screen.width>768 ? heightMenu : heightMenuMobile}px`,
    'marginTop': `-${window.screen.width>768 ? heightMenu : heightMenuMobile}px`,
  });
  $('.gfield_select').on('change', function(e){
    $(this).css('color','black');
  })
  $("#navbar-icon").on("click",function(){
      $(this).addClass("menu-is-activated");
      $('#header__menu-mobile, #header__top-mobile, #header__country, #cover-page-layer, .footer, .page-body').addClass("menu-is-activated");

  });
  $("#cover-page-layer").on("click",function(){
      $(this).removeClass("menu-is-activated");
      $('#header__menu-mobile, #header__top-mobile, #header__country, #navbar-icon, .footer, .page-body').removeClass("menu-is-activated");

  });

  $("#header__menu-mobile .menu-item-has-children").on("click",function(){
    if($(this).hasClass("menu-is-activated")) {
      $(this).removeClass("menu-is-activated")
    }
    else{
      $(this).addClass("menu-is-activated")
    }
  });
  // Animation for special text
  $('.star-custom-animation').each(function(index, value){
    const arrayContent =  $(this).html().trim().split(' ');

    $(this).empty();
    let newContentSplit = '';
    let timeDelay = 1;
    arrayContent.forEach((e,i)=>{
      if(i==0){
         newContentSplit += "<span data-aos='fade-left' data-aos-duration='1000' style='display: inline-block'>"+ e +'</span>';
          timeDelay++;
        }
      else {
        if(e.includes('\n')){
          if(e.indexOf('\n'!=0)){
            newContentSplit += `&nbsp;<span data-aos='fade-left' data-aos-duration='1000' data-aos-delay='${timeDelay}00' style='display: inline-block'>`+ e.slice(0,e.indexOf('\n')) +'</span>' + '<br>' + `&nbsp;<span data-aos='fade-left' data-aos-duration='1000' data-aos-delay='${timeDelay+1}00' style='display: inline-block'>`+ e.slice(e.indexOf('\n')) +'</span>';
            timeDelay=timeDelay+2;
          }
          else{
            newContentSplit += '<br>' + `&nbsp;<span data-aos='fade-left' data-aos-duration='1000' data-aos-delay='${timeDelay}00' style='display: inline-block'>`+ e.slice(e.indexOf('\n')) +'</span>';
            timeDelay=timeDelay+1;
          }
        }
        else{
          timeDelay++;
          newContentSplit += `&nbsp;<span data-aos='fade-left' data-aos-duration='1000' data-aos-delay='${timeDelay}00' style='display: inline-block'>`+ e +'</span>';
        }
      }
    });
    $(this).prepend(newContentSplit);
  });
  $('.star-rotate-animation').each(function(index, value){
    const arrayContent =  $(this).html().trim().split(' ');
    $(this).empty();
    jQuery(this).parent('.star-animation-container').children('.after-start-rotate').attr('data-aos-delay',`${arrayContent.length}000`)
    let newContentSplit = '';
    let timeDelay = 0;
    arrayContent.forEach((e,i)=>{
      if(i==0){
         newContentSplit += "<span data-aos='flip-left' data-aos-duration='1000' style='display: inline-block'>"+ e +'</span>';
          timeDelay++;
        }
      else {
        if(e.includes('\n')){
          if(e.indexOf('\n'!=0)){
            newContentSplit += `&nbsp;<span data-aos='flip-left' data-aos-duration='1000' data-aos-delay='${timeDelay-1}000' style='display: inline-block'>`+ e.slice(0,e.indexOf('\n')) +'</span>' + '<br>' + `&nbsp;<span data-aos='fade-left' data-aos-duration='1000' data-aos-delay='${timeDelay+1}00' style='display: inline-block'>`+ e.slice(e.indexOf('\n')) +'</span>';
            timeDelay=timeDelay+2;
          }
          else{
            newContentSplit += '<br>' + `&nbsp;<span data-aos='flip-left' data-aos-duration='1000' data-aos-delay='${timeDelay-1}000' style='display: inline-block'>`+ e.slice(e.indexOf('\n')) +'</span>';
            timeDelay=timeDelay+1;
          }
        }
        else{
          timeDelay++;
          newContentSplit += `&nbsp;<span data-aos='flip-left' data-aos-duration='1000' data-aos-delay='${timeDelay-1}000' style='display: inline-block'>`+ e +'</span>';
        }
      }
    });
    $(this).prepend(newContentSplit);
  });
  // Scroll event
  let lastPositionToTop = 0;
  $(window).on('scroll',function(){
    let distanceToTop = $(window).scrollTop();
    if(distanceToTop > 32){
      $('#header__menu,#header__country,#header__top-mobile').css({
        'position': 'fixed',
      });
      $('#main').css({
        'paddingTop': `${$('#header__country').height()}`,
        'marginTop': `0`,
      })
    }
    if(distanceToTop <= 32){
      $('#header__menu,#header__country,#header__top-mobile').css({
        'position': 'relative',
      });
      $('#main').css({
        'paddingTop': `${window.screen.width>768 ? heightMenu : heightMenuMobile}px`,
        'marginTop': `-${window.screen.width>768 ? heightMenu : heightMenuMobile}px`,
      })

    }
  })

  $('.scroll-to-div').on("click",function(e){
    e.preventDefault();
    let target = $(this).attr('href');
    $('html, body').animate({
      scrollTop: $(target).offset().top
    }, 100);
  });


  /** Customize play icon of the video section */
  $('.section-video .icon-play').on("click",function(){
    let parentWrapper = $(this).closest('.section-video');
    parentWrapper.find('video')[0].play();
    $(this).hide();
  });

  $('.section-video video').on("pause",function(){
    let parentWrapper = $(this).closest('.section-video');
    parentWrapper.find('.icon-play').show();
  });
  /** End Customize play icon of the video section */

  $('#header__country .country__select select').on('change',function(){
    window.location.href = $(this).val();
  });

  //Call roomvo script
  // $('.call-roomvo-popup').on('click',function(){
  //   ffViz.startStandalone();
  // });
};

main();

jQuery(document).ready(function($){
  AOS.init({
    once: true
  });
  AOS.refresh();
});